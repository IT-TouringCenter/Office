import { Component, OnInit } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Http, Response, Headers, RequestOptions} from '@angular/http';
import { FormsModule, FormControl, Validators } from '@angular/forms';

import { Observable } from "rxjs/Observable";
import "rxjs/Rx";

// Component
import { ProgressBarComponent } from './../../progress/progress-bar/progress-bar.component';
// Services
import { BookingdataServiceService } from './bookingdata-service.service';
import { DataService } from './../../services/data.service';
// Interfaces
import { BookingdataInterface } from './../../interfaces/bookingdata-interface';
import { AccountCodeInterface } from './../../interfaces/account-code-interface';
import { SaveBookingInterface } from './../../interfaces/save-booking-interface';
// import { BookingPrintInterface } from '../../interfaces/booking-print-interface';

@Component({
  selector: 'app-bookingform',
  templateUrl: './bookingform.component.html',
  styleUrls: ['./bookingform.component.scss'],
  providers: [
    BookingdataServiceService,
    DataService
  ]
})
export class BookingformComponent implements OnInit {
  // Set data biding
  travelTime = '';

  // Set model
  tourModel = '';
  dataSave = new Object ;
  guestData = [];

  tourControl = new FormControl('',[Validators.required]);

  // Account code interface
  _getAccountCodeArr: AccountCodeInterface.RootObject;

  // Booking data interface
  _getBookingDataArr: BookingdataInterface.Privacy;

  // Save booking interface
  _saveBookingInterface: SaveBookingInterface.RootObject;

  _getTourTime: BookingdataInterface.Time;
  _getTourPrice: BookingdataInterface.TourPrice;
  _getPrice: BookingdataInterface.Price;
  _getTourPax: BookingdataInterface.Pax;

    constructor(
      private bookingDataService: BookingdataServiceService,
      private dataService: DataService,
      private http: Http
    ) { }

    // JSON booking data
    getBookingData(): void {
      this.bookingDataService.getBookingData()
        .subscribe(
          resultArray => this._getBookingDataArr = resultArray,
          error => console.log("Error :: " + error)
        )
    }

    // JSON account code data
    getAccountCode(): void {
      this.bookingDataService.getAccountCode()
        .subscribe(
          resultArray => this._getAccountCodeArr = resultArray,
          error => console.log("Error :: " + error)
        )
    }

    /*======== Data to Save ========*/
    // Set data booking

    setTourData(){
      this.travelTime = this.tourModel;
      // console.log(this.dataSave);
      // console.log(JSON.stringify(this.tourModel));
      // console.log('+++++++++'+this._getTourTime);
      // this.dataToSave();
    }

    setGuestData(){
      this.guestData = [
        {
          "name": "One 11111",
          "isAges": 1
        },
        {
          "name": "Two 22222",
          "isAges": 2
        },
        {
          "name": "Three 33333",
          "isAges": 3
        }
      ];
    }

    dataToSave(){
      this.setGuestData();
      this.dataSave = 
        {
          "bookingInfo": {
            "tourId": this.tourModel,
            "tourCode": "",
            "tourName": "",
            "tourPrivacy": "",
            "travelTime": "",
            "travelDate": "",
            "pax": 0,
            "adultPax": 0,
            "childPax": 1,
            "infantPax": 0,
            "isServiceCharge": true
          },
          "hotelInfo": {
            "name": "",
            "room": ""
          },
          "guestInfo": this.guestData,
          "paymentInfo": {
            "tourPrice": "",
            "paymentCollect": ""
          },
          "bookBy": {
            "name": "",
            "position": "",
            "code": "",
            "hotel": "",
            "tel": ""
          },
          "insurance": {
            "isInsurance": true,
            "insuranceReason": ""
          },
          "commission":{
            "isCommission": true,
            "amount": 0
          },
          "noteBy": {
            "name": ""
          },
          "summary": {
            "adultPrice": 0,
            "childPrice": 0,
            "totalAdultPrice": 0,
            "totalChildPrice": 0,
            "singleRiding": 0,
            "serviceCharge": 0,
            "discount": 0,
            "discountPrice": 0,
            "amount": 0
          },
          "specialRequest": "",
          "specialRequestPrice": ""
        };

        this.saveDataBooking(this.dataSave);
        // console.log(JSON.stringify(this.dataSave));
    }

    // Save to data service
    saveDataBooking(dataSave) {
      // let content = _dataSave;
      let content = {"bookingInfo":{"tourId":9,"tourCode":"TC-08","tourName":"Chiang Rai One Day","tourPrivacy":"Join","travelTime":"Fullday","travelDate":"23 January 2018","pax":3,"adultPax":2,"childPax":1,"infantPax":0,"isServiceCharge":true},"hotelInfo":{"name":"Ratti Lanna","room":"301"},"guestInfo":[{"name":"One 11111","isAges":1},{"name":"Two 22222","isAges":2},{"name":"Three 33333","isAges":3}],"paymentInfo":{"tourPrice":"Selling Price","paymentCollect":"Voucher"},"bookBy":{"name":"K'A","position":"Concierge","code":"42","hotel":"RattiLanna","tel":"01 234 5678"},"insurance":{"isInsurance":true,"insuranceReason":"คนแรกไม่ส่งประกัน"},"commission":{"isCommission":true,"amount":350},"noteBy":{"name":"Reservation team"},"summary":{"adultPrice":1900,"childPrice":1150,"totalAdultPrice":1900,"totalChildPrice":1150,"singleRiding":300,"serviceCharge":50,"discount":"10%","discountPrice":7500,"amount":3050},"specialRequest":"ไม่กินหมู","specialRequestPrice":500};
      // let content = JSON.stringify(_content);

      let _url = 'http://localhost:9000/api/ReservationSaveBookingData';
      // let _url = 'http://tour-in-chiangmai.com';
      let _headers = new Headers({'Accept': 'application/json','Content-Type': 'text/plain'});
      let _options = new RequestOptions({headers: _headers});

      this.createAuthorizationHeader(_headers);
      _headers.append('Accept','application/json');
      _headers.append('Access-Control-Allow-Origin', '*');
      _headers.append('Access-Control-Allow-Methods', 'POST, GET, OPTIONS, DELETE, PUT');
      _headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
      _headers.append('Access-Control-Allow-Headers', "X-Requested-With, Content-Type, Origin, Authorization, Accept, Client-Security-Token, Accept-Encoding");

      /*==================  Success  ===================*/
      return this.http.post(_url, content, _options)
                      .map(res => res.json())
                      .subscribe(
                        data => {console.log('*-*'+data)},
                        err => {console.log(err)}
                      );
      /*==================  Success  ===================*/
    }

    createAuthorizationHeader(headers:Headers) {
      headers.append('Authorization', 'Basic ' +
        btoa('a20e6aca-ee83-44bc-8033-b41f3078c2b6:c199f9c8-0548-4be79655-7ef7d7bf9d20')); 
      // headers.append('Content-Type', 'application/json');
      // headers.append('Access-Control-Allow-Origin', '*');
      // headers.append('Access-Control-Allow-Methods', 'POST');
      // headers.append('Access-Control-Allow-Headers', 'Content-Type, Authorization');
      // headers.append('Access-Control-Allow-Credentials', 'true');
      // headers.append('Access-Control-Expose-Headers', 'Access-Control-*, Origin, X-Requested-With, Content-Type, Accept, Authorization');
      // headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
      // headers.append('Access-Control-Allow-Methods', 'HEAD, GET, POST, OPTIONS, PUT, PATCH, DELETE');
      // headers.append('Access-Control-Allow-Headers', 'Access-Control-*, Origin, X-Requested-With, Content-Type, Accept, Authorization');
      // headers.append('Access-Control-Allow-Credentials', 'true');
    }

    private handleError(error: Response){
      return Observable.throw(error.statusText);
    }

  ngOnInit() {
    this.getBookingData();
    this.getAccountCode();
    // this.setDataBooking();
  }

}