import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-include-exclude',
  templateUrl: './invoice-include-exclude.component.html',
  styleUrls: ['./invoice-include-exclude.component.scss']
})
export class InvoiceIncludeExcludeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
