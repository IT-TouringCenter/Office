import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-important-note',
  templateUrl: './invoice-important-note.component.html',
  styleUrls: ['./invoice-important-note.component.scss']
})
export class InvoiceImportantNoteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
