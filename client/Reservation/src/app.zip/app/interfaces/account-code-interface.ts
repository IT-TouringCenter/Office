export declare module AccountCodeInterface {
    export interface RootObject {
        code: number;
        hotel: string;
    }
}